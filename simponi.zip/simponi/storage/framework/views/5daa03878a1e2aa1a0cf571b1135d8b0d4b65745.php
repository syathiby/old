<div>
    <a href="/">Home</a>

    <a href="administrasi">Administrasi</a>

    <a href="informasi-akademik">Informasi Akademik</a>

</div><?php /**PATH C:\wamp64\www\simponi\resources\views/layouts/navigasi.blade.php ENDPATH**/ ?>