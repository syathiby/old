

<?php $__env->startSection('title'); ?>
    Halaman Utama
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3>Halaman Utama Aplikasi</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\simponi\resources\views/home.blade.php ENDPATH**/ ?>