@extends('layouts.master')

@section('title')
    Halaman Utama
@endsection

@section('content')
    <h3>Halaman Utama Aplikasi</h3>
@endsection