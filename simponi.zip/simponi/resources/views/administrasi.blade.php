@extends('layouts.master')

@section('title')
    Halaman Administrasi
@endsection

@section('content')
    <h3>Halaman Administrasi</h3>
@endsection