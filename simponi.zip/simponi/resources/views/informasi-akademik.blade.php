@extends('layouts.master')

@section('title')
    Halaman Akademik
@endsection

@section('content')
    <h3>Informasi Akademik</h3>
@endsection